<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="notificationg.css" />
    <link rel="stylesheet" href="notifications.css" />
    <style>
      .frame .group {
  margin-bottom:-400px; /* Adjust this value to control the space between blocks */
}
body{
        overflow-x:hidden;
      }
    </style>
</head>
<body >
<?php include 'navbar.php'; ?>
    <div class="frame"  >
        <div class="div" >
            <div class="overlap">
                <div class="overlap-group">
                    <img class="line" src="https://c.animaapp.com/oGjPm7A1/img/line-22.svg" />
                    <img class="screenshot" src="https://c.animaapp.com/oGjPm7A1/img/screenshot-2023-08-29-112643-2@2x.png" />
                </div>
                <p class="ACC-ROAD-CARE"> <span class="text-wrapper">ACCIDENT  </span><span class="span">SOS</span></p>
            </div>
            <div class="rectangle"></div>
            <div class="text-wrapper-2">Notification</div>
            <div class="group-wrapper">
                <!-- First Set of Content -->
                <?php
        // Database connection
        $db_host = 'localhost';
        $db_user = 'root';
        $db_pass = '';
        $db_name = 'acc_road_care';

        $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Query to select all images from the table
        $sql = "SELECT * FROM signup where alert=1";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // Retrieve the image data
                $id = $row['id'];
                $name = $row['name'];
                $address = $row['address'];
                $vehicle = $row['vehicle'];
                $requestaccepted = $row['requestaccepted'];

                // Generate the HTML for each image with Bootstrap card styling
        
                // echo '<img src="data:image/jpeg;base64,' . base64_encode($image_data) . '" alt="Image"/>';

                echo '<div class="group">';
                echo '<div class="overlap-group-wrapper">';
                echo '<div class="overlap-group-2">';
                echo '<p class="p"><span class="text-wrapper">ACCIDENT </span> <span class="span">SOS</span></p>';
                echo '<div class="overlap-2">';
                echo '<p class="hash-mount-road-LIC">';
                echo '   '.$name.'<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; '.$address.'<br/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    '.$vehicle.'
                                </p>';
               
                echo '</div>';
                echo '<div class="notification"></div>';
                
                if ($requestaccepted == 1) {
                    echo '<img class="correct" src="https://c.animaapp.com/oGjPm7A1/img/icons8-correct-100-1-1@2x.png" />';
                } else {
                    echo '<a href="track.php?id='.$id.'"><img class="emergency" src="https://c.animaapp.com/oGjPm7A1/img/icons8-emergency-50-1@2x.png" /></a>';
                }
                echo '</div>';
                echo '</div>';
                echo '</div>';
            }
           
        } else {
            echo 'No details found in the table.';
        }

        $conn->close();
        ?>
   

                
               
            </div>
        </div>
    </div>
</body>
</html>