<?php include 'navbar.php'; ?>
<?php
session_start();
?>
<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="accinfoperg.css" />
    <link rel="stylesheet" href="accinfopers.css" />
  </head>
  <body>
    <div class="frame">
      <div class="div">
        <img class="line" src="https://c.animaapp.com/kUAUMr2T/img/line-22.svg" />
        <div class="rectangle"></div>
        <div class="overlap-group">
          <div class="group">

            
          <?php

// Database connection
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'acc_road_care';

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the user ID is provided in the query parameter

$helpid = $_SESSION["helpid"];
    // Query to fetch user details by ID
    $sql = "SELECT * FROM signup WHERE id = $helpid";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $name = $row['name'];
        $age = $row['age'];
        $address = $row['address'];
        $id=$row['id'];

        // Display a form for editing user details
        echo '<a href="loctrack.php?id= '.$id.' ">
        <img class="gps" src="https://c.animaapp.com/kUAUMr2T/img/icons8-gps-50-1@2x.png" /></div>
        </a>';
        echo '<p class="information-of-the">
        Information of the accident person:<br /><br />Name&nbsp;&nbsp;: '.$name.'<br />age: '.$age.'<br />D.O.B: 12/3/92<br />Blood
        grp: A+ve<br />Friends: 987*********<br />Accident place: '.$address.'<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        chennai <br />Date: 8/8/2023<br />Timing : 9:45 am
      </p>';
        
    } else {
        echo 'User not found.';
    }


$conn->close();
?>

         
        </div>
        <div class="group-2">
          <p class="ACC-ROAD-CARE"><span class="text-wrapper">ACC </span> <span class="span">ROAD CARE </span></p>
          <img class="screenshot" src="https://c.animaapp.com/kUAUMr2T/img/screenshot-2023-08-29-112643-2@2x.png" />
        </div>
      </div>
    </div>
  </body>
</html>
