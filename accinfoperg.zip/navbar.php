<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="navstyle.css">
</head>
<body>
<nav>
      <input type="checkbox" id="check">
      <label for="check" class="checkbtn">
        <i class="fas fa-bars"></i>
      </label>
      
      <label class="logo">
      <a style="
    position: relative;
    left: -50px;
    top: 5px;
" href="notification.php"><img src="bell.png" alt=""></a>
      </label>
      
      
      <ul>
        <li><a href="home1.php">Home</a></li>
        <li><a href="history.php">History</a></li>
        <li><a href="myfriends.php">Friends</a></li>
        <li><a href="hospitalinfo.php">Hospital Info</a></li>
        <li><a href="feedback1.php">Feedback</a></li>
        <li><a href="profile.php">Profile</a></li>
        <li><a href="login.html">Logout</a></li>
      </ul>
    </nav>
</body>
</html>