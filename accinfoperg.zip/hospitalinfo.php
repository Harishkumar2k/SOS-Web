<?php include 'navbar.php'; ?>
<?php
session_start();
        // Database connection
        $db_host = 'localhost';
        $db_user = 'root';
        $db_pass = '';
        $db_name = 'acc_road_care';

        $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }
        $requestuser = $_SESSION["id"];
        // Query to select all images from the table
        $sql = "SELECT * FROM signup where id=$requestuser";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // Retrieve the image data
                $id = $row['id'];
                $name = $row['name'];
                $attender_id = $row['attender_id'];
            }
           
        } else {
            echo 'No images found in the table.';
        }

        $conn->close();
        ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hospital Info</title> 
    <link rel="stylesheet" href="hospital.css">
    <link rel="stylesheet" href="home1g.css" />
    <link rel="stylesheet" href="home1s.css" />
    <style>
      
    </style>
   </head>
<body>
<div class="bbb" >


  <div class="wrapper" style="margin-left:100px; align-item:center; justify-content:center; text-align:center;">
  <p class="ACC-ROAD-CARE" style="font-size:40px; text-align:center;"><span class="span" style="font-weight:bold;" >ACCIDENT </span> <span style="font-weight:bold; color:red;" class="text-wrapper-2">SOS  </span></p>

    <img src="image/logo img.png" alt="" style="text-align:center;">

    <form action="hospitalinfobk.php" method="POST">
      <div class="input-box">
        <input type="text" name="hospitalname" placeholder="hospitalname" required>
      </div>
      <div class="input-box">
        <input type="text" name="attendername" placeholder="attendername" required>
      </div>
      <div class="input-box">
        <input type="text" name="attendernumber" placeholder="Attendernumber" required>
      </div>
      <div class="input-box">
        <input type="text" name="patientid" value="<?php echo $attender_id; ?>" placeholder="patientid" required>
      </div>
      <div class="input-box">
        <input type="text" name="attenderid" value="<?php echo $id; ?>" placeholder="attenderid" required>
      </div>
      <div class="input-box button">
        <input type="Submit" value="Register Now">
      </div>
    
    </form>
  </div>
  </div>
</body>
</html>