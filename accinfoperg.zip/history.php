<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="notificationg.css" />
    <link rel="stylesheet" href="notifications.css" />
    <style>
        body{
            overflow-x:hidden;
        }
      .frame .group {
  margin-bottom:-400px; /* Adjust this value to control the space between blocks */
}

    </style>
</head>
<body >
<?php include 'navbar.php'; ?>
    <div class="frame"  >
        <div class="div" >
            <div class="overlap">
                <div class="overlap-group">
                    <img class="line" src="https://c.animaapp.com/oGjPm7A1/img/line-22.svg" />
                    <img class="screenshot" src="https://c.animaapp.com/oGjPm7A1/img/screenshot-2023-08-29-112643-2@2x.png" />
                </div>
                <!-- <p class="ACC-ROAD-CARE"><span class="text-wrapper">ACC </span> <span class="span">ROAD CARE +</span></p> -->
                <p class="ACC-ROAD-CARE"> <span class="text-wrapper">ACCIDENT  </span><span class="span">SOS</span></p>

            </div>
            <div class="rectangle"></div>
            <div class="text-wrapper-2">History</div>
            <div class="group-wrapper">
                <!-- First Set of Content -->
                <?php
        // Database connection
        $db_host = 'localhost';
        $db_user = 'root';
        $db_pass = '';
        $db_name = 'acc_road_care';

        $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Query to select all images from the table
        $sql = "SELECT
        H.hospitalname,
        P.username AS patientname,
        A.username AS attendername
    FROM
        hospital_info H
    JOIN
        signup P ON H.patientid = P.id
    JOIN
        signup A ON H.attenderid = A.id;
    ";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // Retrieve the image data
                $hospitalname = $row['hospitalname'];
                $patientname = $row['patientname'];
                $attendername = $row['attendername'];
                

                // Generate the HTML for each image with Bootstrap card styling
        
                // echo '<img src="data:image/jpeg;base64,' . base64_encode($image_data) . '" alt="Image"/>';

                echo '<div class="group">';
                echo '<div class="overlap-group-wrapper">';
                echo '<div class="overlap-group-2">';
                echo '<p class="p"><span class="text-wrapper">ACCIDENT </span> <span class="span">SOS </span></p>';
                echo '<div class="overlap-2">';
                echo '<p class="hash-mount-road-LIC">';
                echo 'MR.'.$attendername.' thanks for helping the person named has '.$patientname.'. He is admited in the '.$hospitalname.' hospital on correct time you can get reward from the hospital Rupees 5000 from the hospital.
                                </p>';
               
                echo '</div>';
                echo '<div class="notification"></div>';
                
                
                echo '</div>';
                echo '</div>';
                echo '</div>';
            }
           
        } else {
            echo 'No images found in the table.';
        }

        $conn->close();
        ?>
   

                
               
            </div>
        </div>
    </div>
</body>
</html>