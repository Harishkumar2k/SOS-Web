<?php include 'navbar.php'; ?>
<?php
session_start();
?>
<?php
                // Database connection
                $db_host = 'localhost';
                $db_user = 'root';
                $db_pass = '';
                $db_name = 'acc_road_care';

                $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }
                
$id = $_SESSION["id"];
                // Query to select all images from the table
                $sql = "SELECT * FROM signup where id='$id'";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        // Retrieve the image data
                        $name = $row['name'];
                        $email = $row['email'];
                        $age = $row['age'];
                        $mobilenumber = $row['mobilenumber'];
                        $bloodgroup = $row['bloodgroup'];
                        $gender = $row['gender'];

                        // Generate the HTML for each image with Bootstrap card styling

                      
                   
                    }
                } else {
                    echo $id;
                    echo 'No images found in the table.';
                }

                $conn->close();
                ?>
<!DOCTYPE html>
<!-- Coding By CodingNepal - codingnepalweb.com -->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Edit Profile </title> 
    <link rel="stylesheet" href="profilestyle.css">
    <style>
      
    </style>
   </head>
<body>
  <div class="wrapper" style="margin-left:700px; align-item:center; justify-content:center; text-align:center;">
  <p class="ACC-ROAD-CARE" style="font-size:40px; text-align:center;"><span class="span" style="font-weight:bold;" >ACCIDENT </span> <span style="font-weight:bold; color:red;" class="text-wrapper-2">SOS  </span></p>

<img src="image/logo img.png" alt="" style="text-align:center;">

    <form action="updatebk.php" method="post">
      <div class="input-box">
        <input type="text" name="name" value="<?php echo $name; ?>" placeholder="Username" required>
      </div>
      <div class="input-box">
        <input type="text" name="gender" placeholder="Gender" value="<?php echo $gender; ?>" required>
      </div>
      <div class="input-box">
        <input type="text" name="mobilenumber" placeholder="Mobile Number" value="<?php echo $mobilenumber; ?>" required>
      </div>
      <div class="input-box">
        <input type="email" name="email" placeholder="Email" value="<?php echo $email; ?>" required>
      </div>
      <div class="input-box">
        <input type="text" name="age" placeholder="Age" value="<?php echo $age; ?>" required>
      </div>
      <div class="input-box">
        <input type="text" name="bloodgroup" placeholder="Bloodgroup" value="<?php echo $bloodgroup; ?>" required>
      </div>
      
     
      <div class="input-box button">
        <input type="Submit" value="Update">
      </div>
     
    </form>
  </div>
</body>
</html>