<?php

 // Database connection
 $db_host = 'localhost';
 $db_user = 'root';
 $db_pass = '';
 $db_name = 'acc_road_care';

 $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
 

 if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
 }
 if(isset($_GET['id'])){
    $id=$_GET['id'];


 // Query to select all images from the table
 $sql = "SELECT * FROM signup where id=$id ";
 $result = $conn->query($sql);

 if ($result->num_rows > 0) {
     while ($row = $result->fetch_assoc()) {
         // Retrieve the image data
         $name = $row['username'];
         $number = $row['mobilenumber'];
         
     
        }
    } else {
        echo 'No data found...';
    }
}
   

   $conn->close();
   ?>
<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="ashag.css" />
    <link rel="stylesheet" href="ashas.css" />
  </head>
  <body>
  <?php include 'navbar.php'; ?>
    <div class="frame">
      <div class="div">
        <div class="overlap-group">
          <img class="line" src="https://c.animaapp.com/Ou5NmDeg/img/line-22.svg" />
          <div class="group">
            <p class="ACC-ROAD-CARE"><span class="text-wrapper">ACCIDENT </span> <span class="span">SOS </span></p>
            <img  class="screenshot"  src="https://c.animaapp.com/Ou5NmDeg/img/screenshot-2023-08-29-112643-2@2x.png" />
          </div>
        </div>
        <div class="rectangle" ></div>
        <div class="group-2" style="width:300px; height:300px;" ></div>
        <div >
        <div style="margin-top:-100px; margin-right:200px;" class="text-wrapper-2"><?php echo $name ?></div>
        <div class="text-wrapper-3">+91 <?php echo $number ?></div>
        </div>
       
      </div>
    </div>
  </body>
</html>
