<?php
    session_start();
?>



<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="navstyle.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
    <link rel="stylesheet" href="home1g.css" />
    <link rel="stylesheet" href="home1s.css" />
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <style>
      body{
        overflow-x:hidden;
      }
      /* Add custom styles for the custom alert */
.custom-alert {
  display: none;
  background-color: green;
  color: #fff;
  padding: 10px;
  text-align: center;
  position: fixed;
  top: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 100%;
  z-index: 1000;
  font-size: 18px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}

.custom-alert i {
  margin-right: 10px;
}
a {
  text-decoration: none; /* Remove underline on the link */
  color: inherit; /* Inherit the color from the parent element */
}

a:active {
  color: inherit; /* Set the active state color to inherit from the parent element */
}
    </style>
  </head>
  <body>
  <nav>
      <input type="checkbox" id="check">
      <label for="check" class="checkbtn">
        <i class="fas fa-bars"></i>
      </label>
      
      <label class="logo">
      <a href="notification.php"><img src="bell.png" alt=""></a>
      </label>
      
      
      <ul>
        <li><a  href="home1.php">Home</a></li>
        <li><a href="history.php">History</a></li>
        <li><a href="myfriends.php">Friends</a></li>
        <li><a href="hospitalinfo.php">Hospital Info</a></li>
        <li><a href="feedback1.php">Feedback</a></li>
        <li><a href="profile.php">Profile</a></li>
        <li><a href="login.html">Logout</a></li>
      </ul>
    </nav>
    <section>
    <div class="frame" style="justify-content:center; text-align:center;margin-left:-70px;">
      <div class="div">
        <div class="group">
         
          <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
         
          
           <div class="text-wrapper">Two Wheeler</div><br><br>  
        
           <input type="radio" style="width:100px; height: 30px;" name="vehicle" value="Two wheeler">
        
        </div>
      
      
        <div class="group-2">
          
         

            <div class="text-wrapper">Four Wheeler</div><br><br>
       
            <input type="radio" style="width:100px; height: 30px;" name="vehicle" value="Four wheeler">
      
        </div>
        
        <img class="screenshot" src="https://c.animaapp.com/61CXDTV0/img/screenshot-2023-08-29-112643-2@2x.png" />
        <p class="ACC-ROAD-CARE" style="font-size:50px; margin-left:100px;"><span class="span">ACCIDENT </span> <span class="text-wrapper-2">SOS  </span></p>
        <!-- <div class="overlap-group-wrapper">
         <button type="submit">alert</button>
        </div> -->
        <div class="overlap-wrapper">
        <input type="button" onclick="getLocationAndSaveAddress()" style="background-color:red; margin-top:-100px; margin-left: -55px;"  class="text-wrapper-4 overlap-group" value="Add location"><br><br><br><br><br><br>
      
         <input type="submit" style="background-color:red; margin-left: -55px;"  class="text-wrapper-4 overlap-group" value="Alert"><br><br><br><br><br><br>
        </form>
        <div class="custom-alert" id="custom-alert">
            <i class="fas fa-bell"></i> Alert has been sent!
          </div>
        <!-- <a href="other.html"> <input type="submit" style="background-color:red;  margin-left: -55px;" class="text-wrapper-4 overlap-group" value="Other"></a> -->
          <!-- <a href="twowheeler.html"><div class="overlap-group"><div class="text-wrapper-4">Other</div></div></a> -->

          
        </div>
        <div class="rectangle"></div>
      </div>
    </div>

    </section>
     
    <script>
        function getLocationAndSaveAddress() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position) {
                    let latitude = position.coords.latitude;
                    let longitude = position.coords.longitude;
                    
                    fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`)
                        .then(response => response.json())
                        .then(data => {
                            if (data.display_name) {
                                let address = data.display_name;
                                let vehicle = document.querySelector('input[name="vehicle"]:checked').value;
                                saveDetailsToDatabase(latitude, longitude, address, vehicle);
                            } else {
                                document.getElementById("location").innerHTML = "Address not found";
                            }
                        })
                        .catch(error => {
                            console.log("Error: " + error);
                        });
                });
            } else {
                alert("Geolocation is not supported by this browser.");
            }
        }

        function saveDetailsToDatabase(latitude, longitude, address) {
            // Send the data to your PHP script for saving to the database
            fetch('alert_action.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    latitude: latitude,
                    longitude: longitude,
                    address: address,
              
                })
            })
            .then(response => response.text())
            .then(data => {
                console.log(data); // Response from your server-side script
            })
            .catch(error => {
                console.log("Error: " + error);
            });
        }
    </script>

    <?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $vehicle = $_POST["vehicle"];
    // Start or resume the session
   

    // Database connection settings
    $servername = "localhost";
    $db_username = "root";
    $db_password = "";
    $dbname = "acc_road_care"; // Replace with your actual database name

    // Create connection
    $conn = new mysqli($servername, $db_username, $db_password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get the user's session ID
    $userId = $_SESSION['id'];

    // Set the 'alert' column to 1 for the user based on their session ID
    $updateQuery = "UPDATE signup SET vehicle = '$vehicle', alert = 1 WHERE id = $userId";

    if ($conn->query($updateQuery) === TRUE) {
        // Use JavaScript to display the custom alert
        echo '<script>
            document.getElementById("custom-alert").style.display = "block";
            setTimeout(function() {
                document.getElementById("custom-alert").style.display = "none";
                // Redirect to the home page
                window.location.href = "home1.php"; // Replace "home.php" with your actual home page URL
            }, 3000); // Hides the alert after 3 seconds
        </script>';
    } else {
        echo "Error updating record: " . $conn->error;
    }

    // Close the database connection
    $conn->close();
}
?>
  </body>
</html>




